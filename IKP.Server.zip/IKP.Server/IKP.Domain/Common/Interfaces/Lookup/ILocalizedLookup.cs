﻿using IKP.Domain.Common.Interfaces.Information;

namespace IKP.Domain.Common.Interfaces.Lookup
{
    public interface ILocalizedLookup : IShortLocalizedLookup, IHasIcon
    {
    }
}
